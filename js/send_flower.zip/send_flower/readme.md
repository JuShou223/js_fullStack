{key:value,...}对象字面量
[]数组
cst.sendFlower();

talk in js
现实世界到js
1. 对象就只有属性和方法
2. 参数 target 形参 xiaomei 实参
target.receiveFlower();
3. 接口 Interface
xiaomei xiaohong 只要实现了同样的方法，就可以互换使用
xiaohong 代理人 代理模式
